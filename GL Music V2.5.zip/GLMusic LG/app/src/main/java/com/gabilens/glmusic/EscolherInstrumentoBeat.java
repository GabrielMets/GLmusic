package com.gabilens.glmusic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class EscolherInstrumentoBeat extends AppCompatActivity {
    private Button kitfunk;
    private Button kittrap;
    private Button kiteletronica;
    private Button kitpop;
    private Button voltar55;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_escolher_instrumento_beat);

        kitfunk = findViewById(R.id.kitfunk);
        kitfunk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), TocarBeatFunk.class);
                startActivity(intent);
            }
        });

        kittrap = findViewById(R.id.kittrap);
        kittrap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), TocarBeatTrap.class);
                startActivity(intent);
            }
        });

        kiteletronica = findViewById(R.id.kiteletronica);
        kiteletronica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), TocarBeatEletronica.class);
                startActivity(intent);
            }
        });

        kitpop = findViewById(R.id.kitpop);
        kitpop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), TocarBeatPop.class);
                startActivity(intent);
            }
        });

        voltar55 = findViewById(R.id.voltar55);
        voltar55.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentvoltar55 = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intentvoltar55);
            }
        });
    }
}
