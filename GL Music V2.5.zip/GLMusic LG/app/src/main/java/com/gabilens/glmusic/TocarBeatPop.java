package com.gabilens.glmusic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TocarBeatPop extends AppCompatActivity {

    private int san = 0;
    private int pre2 = 0;
    private int pre = 0;
    private int hi = 0;
    private int la = 0;
    private MediaPlayer mediaPlayerclap_pop;
    private MediaPlayer mediaPlayerhi_hat_pop;
    private MediaPlayer mediaPlayerkick_pop;
    private MediaPlayer mediaPlayerpre_music1pop;
    private MediaPlayer mediaPlayerpre_music2pop;
    private MediaPlayer mediaPlayerpre_music3pop;
    private MediaPlayer mediaPlayersompop;

    private Button botaovoltar7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tocar_beat_pop);

        botaovoltar7 = findViewById(R.id.botaovoltar7);
        botaovoltar7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentvoltar = new Intent(getApplicationContext(), EscolherInstrumentoBeat.class);
                startActivity(intentvoltar);
                mediaPlayerclap_pop.stop();
                mediaPlayerclap_pop.release();
                mediaPlayerhi_hat_pop.stop();
                mediaPlayerhi_hat_pop.release();
                mediaPlayerkick_pop.stop();
                mediaPlayerkick_pop.release();
                mediaPlayerpre_music1pop.stop();
                mediaPlayerpre_music1pop.release();
                mediaPlayerpre_music2pop.stop();
                mediaPlayerpre_music2pop.release();
                mediaPlayerpre_music3pop.stop();
                mediaPlayerpre_music3pop.release();
                mediaPlayersompop.stop();
                mediaPlayersompop.release();
            }
        });
        mediaPlayerclap_pop = MediaPlayer.create(getApplicationContext(), R.raw.clap_pop);
        mediaPlayerhi_hat_pop = MediaPlayer.create(getApplicationContext(), R.raw.hi_hat_looppop);
        mediaPlayerkick_pop = MediaPlayer.create(getApplicationContext(), R.raw.kickpop);
        mediaPlayerpre_music1pop = MediaPlayer.create(getApplicationContext(), R.raw.pre_music1pop);
        mediaPlayerpre_music2pop = MediaPlayer.create(getApplicationContext(), R.raw.pre_music2pop);
        mediaPlayerpre_music3pop = MediaPlayer.create(getApplicationContext(), R.raw.pre_music3pop);
        mediaPlayersompop = MediaPlayer.create(getApplicationContext(), R.raw.som_pop);
    }

    @Override
    public void onBackPressed() { //Botão BACK padrão do android
        Intent intentvoltar = new Intent(getApplicationContext(), EscolherInstrumentoBeat.class);
        startActivity(intentvoltar);
        mediaPlayerclap_pop.stop();
        mediaPlayerclap_pop.release();
        mediaPlayerhi_hat_pop.stop();
        mediaPlayerhi_hat_pop.release();
        mediaPlayerkick_pop.stop();
        mediaPlayerkick_pop.release();
        mediaPlayerpre_music1pop.stop();
        mediaPlayerpre_music1pop.release();
        mediaPlayerpre_music2pop.stop();
        mediaPlayerpre_music2pop.release();
        mediaPlayerpre_music3pop.stop();
        mediaPlayerpre_music3pop.release();
        mediaPlayersompop.stop();
        mediaPlayersompop.release();
    }

    public void tocar_clappop(View view) {
        if(mediaPlayerclap_pop != null) {
            mediaPlayerclap_pop.start();
        } if( mediaPlayerclap_pop.isPlaying()){
            mediaPlayerclap_pop.seekTo(0);
            mediaPlayerclap_pop.start();
        }
    }
    public void tocar_kickpop(View view) {
        if(mediaPlayerkick_pop != null) {
            mediaPlayerkick_pop.start();
        } if( mediaPlayerkick_pop.isPlaying()){
            mediaPlayerkick_pop.seekTo(0);
            mediaPlayerkick_pop.start();
        }
    }
    public void tocar_sompop(View view) {
        if(mediaPlayersompop != null) {
            mediaPlayersompop.start();
        } if( mediaPlayersompop.isPlaying()){
            mediaPlayersompop.seekTo(0);
            mediaPlayersompop.start();
        }
    }
    public void tocar_hi_hat_pop(View view){
        san = san + 1;
        san = san + 1;
        if (san == 2) {
            mediaPlayerhi_hat_pop.start();
            mediaPlayerhi_hat_pop.setLooping(true);
            san = san + 1;
        }
        if (san == 5){
            mediaPlayerhi_hat_pop.setLooping(false);
            mediaPlayerhi_hat_pop.pause();
            san = 0;
        }
    }

    public void tocar_pre_music1pop(View view){
        hi = hi + 1;
        hi = hi + 1;
        if (hi == 2) {
            mediaPlayerpre_music1pop.start();
            mediaPlayerpre_music1pop.setLooping(true);
            hi = hi + 1;
        }
        if (hi == 5){
            mediaPlayerpre_music1pop.setLooping(false);
            mediaPlayerpre_music1pop.pause();
            hi = 0;
        }
    }

    public void tocar_pre_music2pop(View view){
        pre = pre + 1;
        pre = pre + 1;
        if (pre == 2) {
            mediaPlayerpre_music2pop.start();
            mediaPlayerpre_music2pop.setLooping(true);
            pre = pre + 1;
        }
        if (pre == 5){
            mediaPlayerpre_music2pop.setLooping(false);
            mediaPlayerpre_music2pop.pause();
            pre = 0;
        }
    }

    public void tocar_pre_music3pop(View view){
        pre2 = pre2 + 1;
        pre2 = pre2 + 1;
        if (pre2 == 2) {
            mediaPlayerpre_music3pop.start();
            mediaPlayerpre_music3pop.setLooping(true);
            pre2 = pre2 + 1;
        }
        if (pre2 == 5){
            mediaPlayerpre_music3pop.setLooping(false);
            mediaPlayerpre_music3pop.pause();
            pre2 = 0;
        }
    }

}
