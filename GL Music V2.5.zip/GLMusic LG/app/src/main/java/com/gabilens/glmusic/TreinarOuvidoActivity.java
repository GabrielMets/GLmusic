package com.gabilens.glmusic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class TreinarOuvidoActivity extends AppCompatActivity {
    private Button botaovoltar2;
    private Button buttontreino;
    private Button DOtreino;
    private Button REtreino;
    private Button MItreino;
    private Button FAtreino;
    private Button SOLtreino;
    private Button LAtreino;
    private Button SItreino;
    private Button novalens;
    private TextView textViewtreino;
    private TextView textViewtitulotreino;
    private TextView cc;
    private TextView ccerrado;

    private MediaPlayer mediaPlayerdo;
    private MediaPlayer mediaPlayerre;
    private MediaPlayer mediaPlayermi;
    private MediaPlayer mediaPlayerfa;
    private MediaPlayer mediaPlayersol;
    private MediaPlayer mediaPlayerla;
    private MediaPlayer mediaPlayersi;
    private int toque;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_treinar_ouvido);

        botaovoltar2 = findViewById(R.id.botaovoltar2);
        botaovoltar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentvoltar2 = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intentvoltar2);
                mediaPlayerdo.stop();
                mediaPlayerdo.release();
                mediaPlayerre.stop();
                mediaPlayerre.release();
                mediaPlayermi.stop();
                mediaPlayermi.release();
                mediaPlayerfa.stop();
                mediaPlayerfa.release();
                mediaPlayersol.stop();
                mediaPlayersol.release();
                mediaPlayerla.stop();
                mediaPlayerla.release();
                mediaPlayersi.stop();
                mediaPlayersi.release();
            }
        });

        novalens = findViewById(R.id.novalens);
        novalens.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentvoltar4 = new Intent(getApplicationContext(), TreinarOuvidoActivity.class);
                startActivity(intentvoltar4);

                mediaPlayerdo.stop();
                mediaPlayerdo.release();
                mediaPlayerre.stop();
                mediaPlayerre.release();
                mediaPlayermi.stop();
                mediaPlayermi.release();
                mediaPlayerfa.stop();
                mediaPlayerfa.release();
                mediaPlayersol.stop();
                mediaPlayersol.release();
                mediaPlayerla.stop();
                mediaPlayerla.release();
                mediaPlayersi.stop();
                mediaPlayersi.release();
            }
        });


        cc = findViewById(R.id.cc);
        ccerrado = findViewById(R.id.ccerrado);
        textViewtreino = findViewById(R.id.textViewtreino);
        DOtreino = findViewById(R.id.DOtreino);
        REtreino = findViewById(R.id.REtreino);
        MItreino = findViewById(R.id.MItreino);
        FAtreino = findViewById(R.id.FAtreino);
        SOLtreino = findViewById(R.id.SOLtreino);
        LAtreino = findViewById(R.id.LAtreino);
        SItreino = findViewById(R.id.SItreino);
        buttontreino = findViewById(R.id.buttontreino);
        textViewtitulotreino = findViewById(R.id.textViewtitulotreino);
        novalens = findViewById(R.id.novalens);

        mediaPlayerdo = MediaPlayer.create(getApplicationContext(), R.raw.xdo);
        mediaPlayerre = MediaPlayer.create(getApplicationContext(), R.raw.re);
        mediaPlayermi = MediaPlayer.create(getApplicationContext(), R.raw.mi);
        mediaPlayerfa = MediaPlayer.create(getApplicationContext(), R.raw.fa);
        mediaPlayersol = MediaPlayer.create(getApplicationContext(), R.raw.sol);
        mediaPlayerla = MediaPlayer.create(getApplicationContext(), R.raw.la);
        mediaPlayersi = MediaPlayer.create(getApplicationContext(), R.raw.si);

        textViewtreino.setVisibility(View.INVISIBLE);
        cc.setVisibility(View.INVISIBLE);
        ccerrado.setVisibility(View.INVISIBLE);
        novalens.setVisibility(View.INVISIBLE);

        buttontreino.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Random var = new Random();
                toque = var.nextInt(7) + 1;

                if (toque == 1) {
                    mediaPlayerdo.start();
                }
                if (toque == 2) {
                    mediaPlayerre.start();
                }
                if (toque == 3) {
                    mediaPlayermi.start();
                }
                if (toque == 4) {
                    mediaPlayerfa.start();
                }
                if (toque == 5) {
                    mediaPlayersol.start();
                }
                if (toque == 6) {
                    mediaPlayerla.start();
                }
                if (toque == 7) {
                    mediaPlayersi.start();
                }
                textViewtreino.setVisibility(View.VISIBLE);
                DOtreino.setVisibility(View.VISIBLE);
                REtreino.setVisibility(View.VISIBLE);
                MItreino.setVisibility(View.VISIBLE);
                FAtreino.setVisibility(View.VISIBLE);
                SOLtreino.setVisibility(View.VISIBLE);
                LAtreino.setVisibility(View.VISIBLE);
                SItreino.setVisibility(View.VISIBLE);
                buttontreino.setVisibility(View.INVISIBLE);
                textViewtitulotreino.setVisibility(View.INVISIBLE);


            }
        });
        DOtreino.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewtreino.setVisibility(View.INVISIBLE);
                DOtreino.setVisibility(View.INVISIBLE);
                REtreino.setVisibility(View.INVISIBLE);
                MItreino.setVisibility(View.INVISIBLE);
                FAtreino.setVisibility(View.INVISIBLE);
                SOLtreino.setVisibility(View.INVISIBLE);
                LAtreino.setVisibility(View.INVISIBLE);
                SItreino.setVisibility(View.INVISIBLE);
                novalens.setVisibility(View.VISIBLE);

                if (toque == 1) {
                    cc.setVisibility(View.VISIBLE);
                    DOtreino.setVisibility(View.VISIBLE);
                    ;

                } else
                    ccerrado.setVisibility(View.VISIBLE);
            }
        });

        REtreino.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewtreino.setVisibility(View.INVISIBLE);
                DOtreino.setVisibility(View.INVISIBLE);
                REtreino.setVisibility(View.INVISIBLE);
                MItreino.setVisibility(View.INVISIBLE);
                FAtreino.setVisibility(View.INVISIBLE);
                SOLtreino.setVisibility(View.INVISIBLE);
                LAtreino.setVisibility(View.INVISIBLE);
                SItreino.setVisibility(View.INVISIBLE);
                novalens.setVisibility(View.VISIBLE);

                if (toque == 2) {
                    cc.setVisibility(View.VISIBLE);
                    REtreino.setVisibility(View.VISIBLE);

                } else
                    ccerrado.setVisibility(View.VISIBLE);
            }
        });

        MItreino.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewtreino.setVisibility(View.INVISIBLE);
                REtreino.setVisibility(View.INVISIBLE);
                DOtreino.setVisibility(View.INVISIBLE);
                MItreino.setVisibility(View.INVISIBLE);
                FAtreino.setVisibility(View.INVISIBLE);
                SOLtreino.setVisibility(View.INVISIBLE);
                LAtreino.setVisibility(View.INVISIBLE);
                SItreino.setVisibility(View.INVISIBLE);
                novalens.setVisibility(View.VISIBLE);


                if (toque == 3) {
                    cc.setVisibility(View.VISIBLE);
                    MItreino.setVisibility(View.VISIBLE);


                } else
                    ccerrado.setVisibility(View.VISIBLE);
            }
        });

        FAtreino.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewtreino.setVisibility(View.INVISIBLE);
                DOtreino.setVisibility(View.INVISIBLE);
                REtreino.setVisibility(View.INVISIBLE);
                MItreino.setVisibility(View.INVISIBLE);
                FAtreino.setVisibility(View.INVISIBLE);
                SOLtreino.setVisibility(View.INVISIBLE);
                LAtreino.setVisibility(View.INVISIBLE);
                SItreino.setVisibility(View.INVISIBLE);
                novalens.setVisibility(View.VISIBLE);

                if (toque == 4) {
                    cc.setVisibility(View.VISIBLE);
                    FAtreino.setVisibility(View.VISIBLE);

                } else
                    ccerrado.setVisibility(View.VISIBLE);
            }
        });

        SOLtreino.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewtreino.setVisibility(View.INVISIBLE);
                DOtreino.setVisibility(View.INVISIBLE);
                REtreino.setVisibility(View.INVISIBLE);
                MItreino.setVisibility(View.INVISIBLE);
                FAtreino.setVisibility(View.INVISIBLE);
                SOLtreino.setVisibility(View.INVISIBLE);
                LAtreino.setVisibility(View.INVISIBLE);
                SItreino.setVisibility(View.INVISIBLE);
                novalens.setVisibility(View.VISIBLE);


                if (toque == 5) {
                    cc.setVisibility(View.VISIBLE);
                    SOLtreino.setVisibility(View.VISIBLE);


                } else
                    ccerrado.setVisibility(View.VISIBLE);
            }
        });

        LAtreino.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewtreino.setVisibility(View.INVISIBLE);
                DOtreino.setVisibility(View.INVISIBLE);
                REtreino.setVisibility(View.INVISIBLE);
                MItreino.setVisibility(View.INVISIBLE);
                FAtreino.setVisibility(View.INVISIBLE);
                SOLtreino.setVisibility(View.INVISIBLE);
                LAtreino.setVisibility(View.INVISIBLE);
                SItreino.setVisibility(View.INVISIBLE);
                novalens.setVisibility(View.VISIBLE);

                if (toque == 6) {
                    cc.setVisibility(View.VISIBLE);
                    LAtreino.setVisibility(View.VISIBLE);


                } else
                    ccerrado.setVisibility(View.VISIBLE);
            }
        });

        SItreino.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewtreino.setVisibility(View.INVISIBLE);
                DOtreino.setVisibility(View.INVISIBLE);
                REtreino.setVisibility(View.INVISIBLE);
                MItreino.setVisibility(View.INVISIBLE);
                FAtreino.setVisibility(View.INVISIBLE);
                SOLtreino.setVisibility(View.INVISIBLE);
                LAtreino.setVisibility(View.INVISIBLE);
                SItreino.setVisibility(View.INVISIBLE);
                novalens.setVisibility(View.VISIBLE);


                if (toque == 7) {
                    cc.setVisibility(View.VISIBLE);
                    SItreino.setVisibility(View.VISIBLE);


                } else
                    ccerrado.setVisibility(View.VISIBLE);
            }
        });

    }
    @Override
    public void onBackPressed() { //Botão BACK padrão do android
        Intent intentvoltar2 = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intentvoltar2);
        mediaPlayerdo.stop();
        mediaPlayerdo.release();
        mediaPlayerre.stop();
        mediaPlayerre.release();
        mediaPlayermi.stop();
        mediaPlayermi.release();
        mediaPlayerfa.stop();
        mediaPlayerfa.release();
        mediaPlayersol.stop();
        mediaPlayersol.release();
        mediaPlayerla.stop();
        mediaPlayerla.release();
        mediaPlayersi.stop();
        mediaPlayersi.release();
    }


}
