package com.gabilens.glmusic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TocarNotasFlauta extends AppCompatActivity {

    private MediaPlayer mediaPlayerdoflauta;
    private MediaPlayer mediaPlayerreflauta;
    private MediaPlayer mediaPlayermiflauta;
    private MediaPlayer mediaPlayerfaflauta;
    private MediaPlayer mediaPlayersolflauta;
    private MediaPlayer mediaPlayerlaflauta;
    private MediaPlayer mediaPlayersiflauta;

    private Button voltar3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tocar_notas_flauta);

        voltar3 = findViewById(R.id.voltar3);
        voltar3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentvoltar = new Intent(getApplicationContext(), EscolherInstrumentoActivity.class);
                startActivity(intentvoltar);
                mediaPlayerdoflauta.stop();
                mediaPlayerdoflauta.release();
                mediaPlayerreflauta.stop();
                mediaPlayerreflauta.release();
                mediaPlayermiflauta.stop();
                mediaPlayermiflauta.release();
                mediaPlayerfaflauta.stop();
                mediaPlayerfaflauta.release();
                mediaPlayersolflauta.stop();
                mediaPlayersolflauta.release();
                mediaPlayerlaflauta.stop();
                mediaPlayerlaflauta.release();
                mediaPlayersiflauta.stop();
                mediaPlayersiflauta.release();
            }
        });
        mediaPlayerdoflauta = MediaPlayer.create(getApplicationContext(), R.raw.xdo_flauta);
        mediaPlayerreflauta = MediaPlayer.create(getApplicationContext(), R.raw.re_flauta);
        mediaPlayermiflauta = MediaPlayer.create(getApplicationContext(), R.raw.mi_flauta);
        mediaPlayerfaflauta = MediaPlayer.create(getApplicationContext(), R.raw.fa_flauta);
        mediaPlayersolflauta = MediaPlayer.create(getApplicationContext(), R.raw.sol_flauta);
        mediaPlayerlaflauta = MediaPlayer.create(getApplicationContext(), R.raw.la_flauta);
        mediaPlayersiflauta = MediaPlayer.create(getApplicationContext(), R.raw.si_flauta);
    }

    @Override
    public void onBackPressed() { //Botão BACK padrão do android
        Intent intentvoltar = new Intent(getApplicationContext(), EscolherInstrumentoActivity.class);
        startActivity(intentvoltar);
        mediaPlayerdoflauta.stop();
        mediaPlayerdoflauta.release();
        mediaPlayerreflauta.stop();
        mediaPlayerreflauta.release();
        mediaPlayermiflauta.stop();
        mediaPlayermiflauta.release();
        mediaPlayerfaflauta.stop();
        mediaPlayerfaflauta.release();
        mediaPlayersolflauta.stop();
        mediaPlayersolflauta.release();
        mediaPlayerlaflauta.stop();
        mediaPlayerlaflauta.release();
        mediaPlayersiflauta.stop();
        mediaPlayersiflauta.release();
    }
    public void tocar_notasdoflauta(View view){
        if(mediaPlayerdoflauta != null) {
            mediaPlayerdoflauta.start();
        } if( mediaPlayerdoflauta.isPlaying()){
            mediaPlayerdoflauta.seekTo(0);
            mediaPlayerdoflauta.start();
        }
    }
    public void tocar_notasreflauta(View view){
        if(mediaPlayerreflauta != null) {
            mediaPlayerreflauta.start();
        } if( mediaPlayerreflauta.isPlaying()){
            mediaPlayerreflauta.seekTo(0);
            mediaPlayerreflauta.start();
        }
    }
    public void tocar_notasmiflauta(View view){
        if(mediaPlayermiflauta != null) {
            mediaPlayermiflauta.start();
        } if( mediaPlayermiflauta.isPlaying()){
            mediaPlayermiflauta.seekTo(0);
            mediaPlayermiflauta.start();
        }
    }
    public void tocar_notasfaflauta(View view){
        if(mediaPlayerfaflauta != null) {
            mediaPlayerfaflauta.start();
        } if( mediaPlayerfaflauta.isPlaying()){
            mediaPlayerfaflauta.seekTo(0);
            mediaPlayerfaflauta.start();
        }
    }
    public void tocar_notassolflauta(View view){
        if(mediaPlayersolflauta != null) {
            mediaPlayersolflauta.start();
        } if( mediaPlayersolflauta.isPlaying()){
            mediaPlayersolflauta.seekTo(0);
            mediaPlayersolflauta.start();
        }
    }
    public void tocar_notaslaflauta(View view){
        if(mediaPlayerlaflauta != null) {
            mediaPlayerlaflauta.start();
        } if( mediaPlayerlaflauta.isPlaying()){
            mediaPlayerlaflauta.seekTo(0);
            mediaPlayerlaflauta.start();
        }
    }
    public void tocar_notassiflauta(View view){
        if(mediaPlayersiflauta != null) {
            mediaPlayersiflauta.start();
        } if( mediaPlayersiflauta.isPlaying()){
            mediaPlayersiflauta.seekTo(0);
            mediaPlayersiflauta.start();
        }
    }
}
