package com.gabilens.glmusic;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;

public class TocarBeatEletronica extends AppCompatActivity {

    private int san = 0;
    private int pre2 = 0;
    private int pre = 0;
    private int hi = 0;
    private int la = 0;
    private MediaPlayer mediaPlayerclap;
    private MediaPlayer mediaPlayerclap_efect;
    private MediaPlayer mediaPlayerhi_hat_lopp;
    private MediaPlayer mediaPlayerkick;
    private MediaPlayer mediaPlayerpre_music1;
    private MediaPlayer mediaPlayerpre_music2;
    private MediaPlayer mediaPlayersanple1;

    private Button botaovoltar3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_criar_beat_eletronica);

        botaovoltar3 = findViewById(R.id.botaovoltar3);
        botaovoltar3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentvoltar = new Intent(getApplicationContext(), EscolherInstrumentoBeat.class);
                startActivity(intentvoltar);
                mediaPlayerclap.stop();
                mediaPlayerclap.release();
                mediaPlayerclap_efect.stop();
                mediaPlayerclap_efect.release();
                mediaPlayerkick.stop();
                mediaPlayerkick.release();
                mediaPlayerhi_hat_lopp.stop();
                mediaPlayerhi_hat_lopp.release();
                mediaPlayerpre_music1.stop();
                mediaPlayerpre_music1.release();
                mediaPlayerpre_music2.stop();
                mediaPlayerpre_music2.release();
                mediaPlayersanple1.stop();
                mediaPlayersanple1.release();
            }
        });
        mediaPlayerclap = MediaPlayer.create(getApplicationContext(), R.raw.clap);
        mediaPlayerclap_efect = MediaPlayer.create(getApplicationContext(), R.raw.clap_efect);
        mediaPlayerhi_hat_lopp = MediaPlayer.create(getApplicationContext(), R.raw.hi_hat_loop);
        mediaPlayerkick = MediaPlayer.create(getApplicationContext(), R.raw.kick);
        mediaPlayerpre_music1 = MediaPlayer.create(getApplicationContext(), R.raw.pre_music1);
        mediaPlayerpre_music2 = MediaPlayer.create(getApplicationContext(), R.raw.pre_music2);
        mediaPlayersanple1 = MediaPlayer.create(getApplicationContext(), R.raw.sanple1);
    }


    @Override
    public void onBackPressed(){ //Botão BACK padrão do android
        Intent intentvoltar = new Intent(getApplicationContext(), EscolherInstrumentoBeat.class);
        startActivity(intentvoltar);
        mediaPlayerclap.stop();
        mediaPlayerclap.release();
        mediaPlayerclap_efect.stop();
        mediaPlayerclap_efect.release();
        mediaPlayerkick.stop();
        mediaPlayerkick.release();
        mediaPlayerhi_hat_lopp.stop();
        mediaPlayerhi_hat_lopp.release();
        mediaPlayerpre_music1.stop();
        mediaPlayerpre_music1.release();
        mediaPlayerpre_music2.stop();
        mediaPlayerpre_music2.release();
        mediaPlayersanple1.stop();
        mediaPlayersanple1.release();

    }

    public void tocar_clap(View view) {
            if(mediaPlayerclap != null) {
                mediaPlayerclap.start();
            } if( mediaPlayerclap.isPlaying()){
                mediaPlayerclap.seekTo(0);
                mediaPlayerclap.start();
            }
        }


    public void tocar_clap_efect(View view){
        if(mediaPlayerclap_efect != null) {
            mediaPlayerclap_efect.start();
        } if( mediaPlayerclap_efect.isPlaying()){
            mediaPlayerclap_efect.seekTo(0);
            mediaPlayerclap_efect.start();
        }
    }
    public void tocar_hi_hat(View view){
            hi = hi + 1;
        hi = hi + 1;
            if (hi == 2) {
                mediaPlayerhi_hat_lopp.start();
                mediaPlayerhi_hat_lopp.setLooping(true);
                hi = hi + 1;
            }
            if (hi == 5){
                mediaPlayerhi_hat_lopp.setLooping(false);
                mediaPlayerhi_hat_lopp.pause();
                hi = 0;
            }
        }

        public void tocar_kick(View view){
        if(mediaPlayerkick != null) {
            mediaPlayerkick.start();
        } if( mediaPlayerkick.isPlaying()){
            mediaPlayerkick.seekTo(0);
            mediaPlayerkick.start();
        }
    }
    public void tocar_pre_music1(View view){
            pre = pre + 1;
        pre = pre + 1;
            if (pre == 2) {
                mediaPlayerpre_music1.start();
                mediaPlayerpre_music1.setLooping(true);
                pre = pre + 1;
            }
            if (pre == 5){
                mediaPlayerpre_music1.setLooping(false);
                mediaPlayerpre_music1.pause();
                pre = 0;
            }
        }
    public void tocar_pre_music2(View view){
            pre2 = pre2 + 1;
        pre2 = pre2 + 1;
            if (pre2 == 2) {
                mediaPlayerpre_music2.start();
                mediaPlayerpre_music2.setLooping(true);
                pre2 = pre2 + 1;
            }
            if (pre2 == 5){
                mediaPlayerpre_music2.setLooping(false);
                mediaPlayerpre_music2.pause();
                pre2 = 0;
            }
        }
    public void tocar_sanple1(View view){
            san = san + 1;
        san = san + 1;
            if (san == 2) {
                mediaPlayersanple1.start();
                mediaPlayersanple1.setLooping(true);
                san = san + 1;
            }
            if (san == 5){
                mediaPlayersanple1.setLooping(false);
                mediaPlayersanple1.pause();
                san = 0;
            }
        }
}





