package com.gabilens.glmusic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button tocarnotas;
    private Button aprendernotas;
    private Button treinarouvido;
    private Button criarbeat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tocarnotas = findViewById(R.id.tocarnotas);
        tocarnotas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), EscolherInstrumentoActivity.class);
                startActivity(intent);
            }
        });
        aprendernotas = findViewById(R.id.aprendernotas);
        aprendernotas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(getApplicationContext(), AprenderNotasActivity.class);
                startActivity(intent1);
            }
        });
        treinarouvido = findViewById(R.id.treinarouvido);
        treinarouvido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(getApplicationContext(), TreinarOuvidoActivity.class);
                startActivity(intent2);
            }
        });
        criarbeat = findViewById(R.id.criarbeat);
        criarbeat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3 = new Intent(getApplicationContext(), EscolherInstrumentoBeat.class);
                startActivity(intent3);
            }
        });
    }
}
