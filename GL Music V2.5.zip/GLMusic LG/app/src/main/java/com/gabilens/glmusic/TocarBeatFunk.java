package com.gabilens.glmusic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TocarBeatFunk extends AppCompatActivity {

    private int san = 0;
    private int pre2 = 0;
    private int pre = 0;
    private int hi = 0;
    private int la = 0;
    private MediaPlayer mediaPlayerclap_funk;
    private MediaPlayer mediaPlayerentaovaifunk;
    private MediaPlayer mediaPlayerhahahafunk;
    private MediaPlayer mediaPlayerpre_music1funk;
    private MediaPlayer mediaPlayerpre_music2funk;
    private MediaPlayer mediaPlayerohhfunk;
    private MediaPlayer mediaPlayerbeatfunk;

    private Button botaovoltar44;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tocar_beat_funk);

        botaovoltar44 = findViewById(R.id.botaovoltar44);
        botaovoltar44.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentvoltar = new Intent(getApplicationContext(), EscolherInstrumentoBeat.class);
                startActivity(intentvoltar);
                mediaPlayerclap_funk.stop();
                mediaPlayerclap_funk.release();
                mediaPlayerentaovaifunk.stop();
                mediaPlayerentaovaifunk.release();
                mediaPlayerhahahafunk.stop();
                mediaPlayerhahahafunk.release();
                mediaPlayerpre_music1funk.stop();
                mediaPlayerpre_music1funk.release();
                mediaPlayerpre_music2funk.stop();
                mediaPlayerpre_music2funk.release();
                mediaPlayerohhfunk.stop();
                mediaPlayerohhfunk.release();
                mediaPlayerbeatfunk.stop();
                mediaPlayerbeatfunk.release();
            }
        });
        mediaPlayerclap_funk = MediaPlayer.create(getApplicationContext(), R.raw.clap_funk);
        mediaPlayerentaovaifunk = MediaPlayer.create(getApplicationContext(), R.raw.entaovaifunk);
        mediaPlayerhahahafunk = MediaPlayer.create(getApplicationContext(), R.raw.hahahafunk);
        mediaPlayerpre_music1funk = MediaPlayer.create(getApplicationContext(), R.raw.pre_music1funk);
        mediaPlayerpre_music2funk = MediaPlayer.create(getApplicationContext(), R.raw.pre_music2funk);
        mediaPlayerohhfunk = MediaPlayer.create(getApplicationContext(), R.raw.ohhfunk);
        mediaPlayerbeatfunk = MediaPlayer.create(getApplicationContext(), R.raw.beatfunk);
    }

    @Override
    public void onBackPressed(){ //Botão BACK padrão do android
        Intent intentvoltar = new Intent(getApplicationContext(), EscolherInstrumentoBeat.class);
        startActivity(intentvoltar);
        mediaPlayerclap_funk.stop();
        mediaPlayerclap_funk.release();
        mediaPlayerentaovaifunk.stop();
        mediaPlayerentaovaifunk.release();
        mediaPlayerhahahafunk.stop();
        mediaPlayerhahahafunk.release();
        mediaPlayerpre_music1funk.stop();
        mediaPlayerpre_music1funk.release();
        mediaPlayerpre_music2funk.stop();
        mediaPlayerpre_music2funk.release();
        mediaPlayerohhfunk.stop();
        mediaPlayerohhfunk.release();
        mediaPlayerbeatfunk.stop();
        mediaPlayerbeatfunk.release();
    }

    public void tocar_clapfunk(View view) {
        if(mediaPlayerclap_funk != null) {
            mediaPlayerclap_funk.start();
        } if( mediaPlayerclap_funk.isPlaying()){
            mediaPlayerclap_funk.seekTo(0);
            mediaPlayerclap_funk.start();
        }
    }

    public void tocar_entaovai(View view) {
        if(mediaPlayerentaovaifunk != null) {
            mediaPlayerentaovaifunk.start();
        } if( mediaPlayerentaovaifunk.isPlaying()){
            mediaPlayerentaovaifunk.seekTo(0);
            mediaPlayerentaovaifunk.start();
        }
    }

    public void tocar_hahahafunk(View view){
        san = san + 1;
        san = san + 1;
        if (san == 2) {
            mediaPlayerhahahafunk.start();
            mediaPlayerhahahafunk.setLooping(true);
            san = san + 1;
        }
        if (san == 5){
            mediaPlayerhahahafunk.setLooping(false);
            mediaPlayerhahahafunk.pause();
            san = 0;
        }
    }

    public void tocar_ohhfunk(View view) {
        if(mediaPlayerohhfunk != null) {
            mediaPlayerohhfunk.start();
        } if( mediaPlayerohhfunk.isPlaying()){
            mediaPlayerohhfunk.seekTo(0);
            mediaPlayerohhfunk.start();
        }
    }

    public void tocar_beatfunk(View view){
        hi = hi + 1;
        hi = hi + 1;
        if (hi == 2) {
            mediaPlayerbeatfunk.start();
            mediaPlayerbeatfunk.setLooping(true);
            hi = hi + 1;
        }
        if (hi == 5){
            mediaPlayerbeatfunk.setLooping(false);
            mediaPlayerbeatfunk.pause();
            hi = 0;
        }
    }
    public void tocar_pre_music1funk(View view){
        pre = pre + 1;
        pre = pre + 1;
        if (pre == 2) {
            mediaPlayerpre_music1funk.start();
            mediaPlayerpre_music1funk.setLooping(true);
            pre = pre + 1;
        }
        if (pre == 5){
            mediaPlayerpre_music1funk.setLooping(false);
            mediaPlayerpre_music1funk.pause();
            pre = 0;
        }
    }
    public void tocar_pre_music2funk(View view){
        pre2 = pre2 + 1;
        pre2 = pre2 + 1;
        if (pre2 == 2) {
            mediaPlayerpre_music2funk.start();
            mediaPlayerpre_music2funk.setLooping(true);
            pre2 = pre2 + 1;
        }
        if (pre2 == 5){
            mediaPlayerpre_music2funk.setLooping(false);
            mediaPlayerpre_music2funk.pause();
            pre2 = 0;
        }
    }

}
