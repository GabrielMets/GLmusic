package com.gabilens.glmusic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TocarNotasViolao extends AppCompatActivity {

    private MediaPlayer mediaPlayerdoviolao;
    private MediaPlayer mediaPlayerreviolao;
    private MediaPlayer mediaPlayermiviolao;
    private MediaPlayer mediaPlayerfaviolao;
    private MediaPlayer mediaPlayersolviolao;
    private MediaPlayer mediaPlayerlaviolao;
    private MediaPlayer mediaPlayersiviolao;

    private Button voltar2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tocar_notas_violao);

        voltar2 = findViewById(R.id.voltar2);
        voltar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentvoltar = new Intent(getApplicationContext(), EscolherInstrumentoActivity.class);
                startActivity(intentvoltar);
                mediaPlayerdoviolao.stop();
                mediaPlayerdoviolao.release();
                mediaPlayerreviolao.stop();
                mediaPlayerreviolao.release();
                mediaPlayermiviolao.stop();
                mediaPlayermiviolao.release();
                mediaPlayerfaviolao.stop();
                mediaPlayerfaviolao.release();
                mediaPlayersolviolao.stop();
                mediaPlayersolviolao.release();
                mediaPlayerlaviolao.stop();
                mediaPlayerlaviolao.release();
                mediaPlayersiviolao.stop();
                mediaPlayersiviolao.release();
            }
        });
        mediaPlayerdoviolao = MediaPlayer.create(getApplicationContext(), R.raw.xdo_violao);
        mediaPlayerreviolao = MediaPlayer.create(getApplicationContext(), R.raw.re_violao);
        mediaPlayermiviolao = MediaPlayer.create(getApplicationContext(), R.raw.mi_violao);
        mediaPlayerfaviolao = MediaPlayer.create(getApplicationContext(), R.raw.fa_violao);
        mediaPlayersolviolao = MediaPlayer.create(getApplicationContext(), R.raw.sol_violao);
        mediaPlayerlaviolao = MediaPlayer.create(getApplicationContext(), R.raw.la_violao);
        mediaPlayersiviolao = MediaPlayer.create(getApplicationContext(), R.raw.si_violao);
    }
    @Override
    public void onBackPressed() { //Botão BACK padrão do android
        Intent intentvoltar = new Intent(getApplicationContext(), EscolherInstrumentoActivity.class);
        startActivity(intentvoltar);
        mediaPlayerdoviolao.stop();
        mediaPlayerdoviolao.release();
        mediaPlayerreviolao.stop();
        mediaPlayerreviolao.release();
        mediaPlayermiviolao.stop();
        mediaPlayermiviolao.release();
        mediaPlayerfaviolao.stop();
        mediaPlayerfaviolao.release();
        mediaPlayersolviolao.stop();
        mediaPlayersolviolao.release();
        mediaPlayerlaviolao.stop();
        mediaPlayerlaviolao.release();
        mediaPlayersiviolao.stop();
        mediaPlayersiviolao.release();
    }
    public void tocar_notasdoviolao(View view){
        if(mediaPlayerdoviolao != null) {
            mediaPlayerdoviolao.start();
        } if( mediaPlayerdoviolao.isPlaying()){
            mediaPlayerdoviolao.seekTo(0);
            mediaPlayerdoviolao.start();
        }
    }
    public void tocar_notasreviolao(View view){
        if(mediaPlayerreviolao != null) {
            mediaPlayerreviolao.start();
        } if( mediaPlayerreviolao.isPlaying()){
            mediaPlayerreviolao.seekTo(0);
            mediaPlayerreviolao.start();
        }
    }
    public void tocar_notasmiviolao(View view){
        if(mediaPlayermiviolao != null) {
            mediaPlayermiviolao.start();
        } if( mediaPlayermiviolao.isPlaying()){
            mediaPlayermiviolao.seekTo(0);
            mediaPlayermiviolao.start();
        }
    }
    public void tocar_notasfaviolao(View view){
        if(mediaPlayerfaviolao != null) {
            mediaPlayerfaviolao.start();
        } if( mediaPlayerfaviolao.isPlaying()){
            mediaPlayerfaviolao.seekTo(0);
            mediaPlayerfaviolao.start();
        }
    }
    public void tocar_notassolviolao(View view){
        if(mediaPlayersolviolao != null) {
            mediaPlayersolviolao.start();
        } if( mediaPlayersolviolao.isPlaying()){
            mediaPlayersolviolao.seekTo(0);
            mediaPlayersolviolao.start();
        }
    }
    public void tocar_notaslaviolao(View view){
        if(mediaPlayerlaviolao != null) {
            mediaPlayerlaviolao.start();
        } if( mediaPlayerlaviolao.isPlaying()){
            mediaPlayerlaviolao.seekTo(0);
            mediaPlayerlaviolao.start();
        }
    }
    public void tocar_notassiviolao(View view){
        if(mediaPlayersiviolao != null) {
            mediaPlayersiviolao.start();
        } if( mediaPlayersiviolao.isPlaying()){
            mediaPlayersiviolao.seekTo(0);
            mediaPlayersiviolao.start();
        }
    }
}
