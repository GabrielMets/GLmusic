package com.gabilens.glmusic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TocarNotasGuitarra extends AppCompatActivity {

    private MediaPlayer mediaPlayerdoguitarra;
    private MediaPlayer mediaPlayerreguitarra;
    private MediaPlayer mediaPlayermiguitarra;
    private MediaPlayer mediaPlayerfaguitarra;
    private MediaPlayer mediaPlayersolguitarra;
    private MediaPlayer mediaPlayerlaguitarra;
    private MediaPlayer mediaPlayersiguitarra;

    private Button voltar4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tocar_notas_guitarra);

        voltar4 = findViewById(R.id.voltar4);
        voltar4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentvoltar = new Intent(getApplicationContext(), EscolherInstrumentoActivity.class);
                startActivity(intentvoltar);
                mediaPlayerdoguitarra.stop();
                mediaPlayerdoguitarra.release();
                mediaPlayerreguitarra.stop();
                mediaPlayerreguitarra.release();
                mediaPlayermiguitarra.stop();
                mediaPlayermiguitarra.release();
                mediaPlayerfaguitarra.stop();
                mediaPlayerfaguitarra.release();
                mediaPlayersolguitarra.stop();
                mediaPlayersolguitarra.release();
                mediaPlayerlaguitarra.stop();
                mediaPlayerlaguitarra.release();
                mediaPlayersiguitarra.stop();
                mediaPlayersiguitarra.release();
            }
        });
        mediaPlayerdoguitarra = MediaPlayer.create(getApplicationContext(), R.raw.xdo_guitarra);
        mediaPlayerreguitarra = MediaPlayer.create(getApplicationContext(), R.raw.re_guitarra);
        mediaPlayermiguitarra = MediaPlayer.create(getApplicationContext(), R.raw.mi_guitarra);
        mediaPlayerfaguitarra = MediaPlayer.create(getApplicationContext(), R.raw.fa_guitarra);
        mediaPlayersolguitarra = MediaPlayer.create(getApplicationContext(), R.raw.sol_guitarra);
        mediaPlayerlaguitarra = MediaPlayer.create(getApplicationContext(), R.raw.la_guitarra);
        mediaPlayersiguitarra = MediaPlayer.create(getApplicationContext(), R.raw.si_guitarra);
    }

    @Override
    public void onBackPressed() { //Botão BACK padrão do android
        Intent intentvoltar = new Intent(getApplicationContext(), EscolherInstrumentoActivity.class);
        startActivity(intentvoltar);
        mediaPlayerdoguitarra.stop();
        mediaPlayerdoguitarra.release();
        mediaPlayerreguitarra.stop();
        mediaPlayerreguitarra.release();
        mediaPlayermiguitarra.stop();
        mediaPlayermiguitarra.release();
        mediaPlayerfaguitarra.stop();
        mediaPlayerfaguitarra.release();
        mediaPlayersolguitarra.stop();
        mediaPlayersolguitarra.release();
        mediaPlayerlaguitarra.stop();
        mediaPlayerlaguitarra.release();
        mediaPlayersiguitarra.stop();
        mediaPlayersiguitarra.release();
    }
    public void tocar_notasdoguitarra(View view){
        if(mediaPlayerdoguitarra != null) {
            mediaPlayerdoguitarra.start();
        } if( mediaPlayerdoguitarra.isPlaying()){
            mediaPlayerdoguitarra.seekTo(0);
            mediaPlayerdoguitarra.start();
        }
    }
    public void tocar_notasreguitarra(View view){
        if(mediaPlayerreguitarra != null) {
            mediaPlayerreguitarra.start();
        } if( mediaPlayerreguitarra.isPlaying()){
            mediaPlayerreguitarra.seekTo(0);
            mediaPlayerreguitarra.start();
        }
    }
    public void tocar_notasmiguitarra(View view){
        if(mediaPlayermiguitarra != null) {
            mediaPlayermiguitarra.start();
        } if( mediaPlayermiguitarra.isPlaying()){
            mediaPlayermiguitarra.seekTo(0);
            mediaPlayermiguitarra.start();
        }
    }
    public void tocar_notasfaguitarra(View view){
        if(mediaPlayerfaguitarra != null) {
            mediaPlayerfaguitarra.start();
        } if( mediaPlayerfaguitarra.isPlaying()){
            mediaPlayerfaguitarra.seekTo(0);
            mediaPlayerfaguitarra.start();
        }
    }
    public void tocar_notassolguitarra(View view){
        if(mediaPlayersolguitarra != null) {
            mediaPlayersolguitarra.start();
        } if( mediaPlayersolguitarra.isPlaying()){
            mediaPlayersolguitarra.seekTo(0);
            mediaPlayersolguitarra.start();
        }
    }
    public void tocar_notaslaguitarra(View view){
        if(mediaPlayerlaguitarra != null) {
            mediaPlayerlaguitarra.start();
        } if( mediaPlayerlaguitarra.isPlaying()){
            mediaPlayerlaguitarra.seekTo(0);
            mediaPlayerlaguitarra.start();
        }
    }
    public void tocar_notassiguitarra(View view){
        if(mediaPlayersiguitarra != null) {
            mediaPlayersiguitarra.start();
        } if( mediaPlayersiguitarra.isPlaying()){
            mediaPlayersiguitarra.seekTo(0);
            mediaPlayersiguitarra.start();
        }
    }
}

