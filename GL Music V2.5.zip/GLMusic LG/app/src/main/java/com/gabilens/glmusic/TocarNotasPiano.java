package com.gabilens.glmusic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TocarNotasPiano extends AppCompatActivity {

    private MediaPlayer mediaPlayerdo;
    private MediaPlayer mediaPlayerre;
    private MediaPlayer mediaPlayermi;
    private MediaPlayer mediaPlayerfa;
    private MediaPlayer mediaPlayersol;
    private MediaPlayer mediaPlayerla;
    private MediaPlayer mediaPlayersi;

    private Button botaovoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tocar_notas_piano);

        botaovoltar = findViewById(R.id.botaovoltar);
        botaovoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentvoltar = new Intent(getApplicationContext(), EscolherInstrumentoActivity.class);
                startActivity(intentvoltar);
                mediaPlayerdo.stop();
                mediaPlayerdo.release();
                mediaPlayerre.stop();
                mediaPlayerre.release();
                mediaPlayermi.stop();
                mediaPlayermi.release();
                mediaPlayerfa.stop();
                mediaPlayerfa.release();
                mediaPlayersol.stop();
                mediaPlayersol.release();
                mediaPlayerla.stop();
                mediaPlayerla.release();
                mediaPlayersi.stop();
                mediaPlayersi.release();
            }
        });
        mediaPlayerdo = MediaPlayer.create(getApplicationContext(), R.raw.xdo);
        mediaPlayerre = MediaPlayer.create(getApplicationContext(), R.raw.re);
        mediaPlayermi = MediaPlayer.create(getApplicationContext(), R.raw.mi);
        mediaPlayerfa = MediaPlayer.create(getApplicationContext(), R.raw.fa);
        mediaPlayersol = MediaPlayer.create(getApplicationContext(), R.raw.sol);
        mediaPlayerla = MediaPlayer.create(getApplicationContext(), R.raw.la);
        mediaPlayersi = MediaPlayer.create(getApplicationContext(), R.raw.si);
    }

    @Override
    public void onBackPressed() { //Botão BACK padrão do android
        Intent intentvoltar = new Intent(getApplicationContext(), EscolherInstrumentoActivity.class);
        startActivity(intentvoltar);
        mediaPlayerdo.stop();
        mediaPlayerdo.release();
        mediaPlayerre.stop();
        mediaPlayerre.release();
        mediaPlayermi.stop();
        mediaPlayermi.release();
        mediaPlayerfa.stop();
        mediaPlayerfa.release();
        mediaPlayersol.stop();
        mediaPlayersol.release();
        mediaPlayerla.stop();
        mediaPlayerla.release();
        mediaPlayersi.stop();
        mediaPlayersi.release();
    }
    public void tocar_notasdo(View view){
        if(mediaPlayerdo != null) {
            mediaPlayerdo.start();
        } if( mediaPlayerdo.isPlaying()){
            mediaPlayerdo.seekTo(0);
            mediaPlayerdo.start();
        }
    }
    public void tocar_notasre(View view){
        if(mediaPlayerre != null) {
            mediaPlayerre.start();
        } if( mediaPlayerre.isPlaying()){
            mediaPlayerre.seekTo(0);
            mediaPlayerre.start();
        }
    }
    public void tocar_notasmi(View view){
        if(mediaPlayermi != null) {
            mediaPlayermi.start();
        } if( mediaPlayermi.isPlaying()){
            mediaPlayermi.seekTo(0);
            mediaPlayermi.start();
        }
    }
    public void tocar_notasfa(View view){
        if(mediaPlayerfa != null) {
            mediaPlayerfa.start();
        } if( mediaPlayerfa.isPlaying()){
            mediaPlayerfa.seekTo(0);
            mediaPlayerfa.start();
        }
    }
    public void tocar_notassol(View view){
        if(mediaPlayersol != null) {
            mediaPlayersol.start();
        } if( mediaPlayersol.isPlaying()){
            mediaPlayersol.seekTo(0);
            mediaPlayersol.start();
        }
    }
    public void tocar_notasla(View view){
        if(mediaPlayerla != null) {
            mediaPlayerla.start();
        } if( mediaPlayerla.isPlaying()){
            mediaPlayerla.seekTo(0);
            mediaPlayerla.start();
        }
    }
    public void tocar_notassi(View view){
        if(mediaPlayersi != null) {
            mediaPlayersi.start();
        } if( mediaPlayersi.isPlaying()){
                mediaPlayersi.seekTo(0);
                mediaPlayersi.start();
            }
        }
    }




