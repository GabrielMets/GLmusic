package com.gabilens.glmusic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TocarBeatTrap extends AppCompatActivity {

    private int san = 0;
    private int pre2 = 0;
    private int pre = 0;
    private int hi = 0;
    private int la = 0;
    private MediaPlayer mediaPlayerclaptrap;
    private MediaPlayer mediaPlayerhi_hattrap;
    private MediaPlayer mediaPlayerkicktrap;
    private MediaPlayer mediaPlayerpre_music1trap;
    private MediaPlayer mediaPlayerfx_trap;
    private MediaPlayer mediaPlayeroito08;
    private MediaPlayer mediaPlayerbeattrap;

    private Button botaovoltar8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tocar_beat_trap);

        botaovoltar8 = findViewById(R.id.botaovoltar8);
        botaovoltar8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentvoltar = new Intent(getApplicationContext(), EscolherInstrumentoBeat.class);
                startActivity(intentvoltar);
                mediaPlayerclaptrap.stop();
                mediaPlayerclaptrap.release();
                mediaPlayerhi_hattrap.stop();
                mediaPlayerhi_hattrap.release();
                mediaPlayerkicktrap.stop();
                mediaPlayerkicktrap.release();
                mediaPlayerpre_music1trap.stop();
                mediaPlayerpre_music1trap.release();
                mediaPlayerfx_trap.stop();
                mediaPlayerfx_trap.release();
                mediaPlayeroito08.stop();
                mediaPlayeroito08.release();
                mediaPlayerbeattrap.stop();
                mediaPlayerbeattrap.release();
            }
        });
        mediaPlayerclaptrap = MediaPlayer.create(getApplicationContext(), R.raw.claptrap);
        mediaPlayerhi_hattrap = MediaPlayer.create(getApplicationContext(), R.raw.hi_hattrap);
        mediaPlayerkicktrap = MediaPlayer.create(getApplicationContext(), R.raw.kicktrap);
        mediaPlayerpre_music1trap = MediaPlayer.create(getApplicationContext(), R.raw.pre_music1trap);
        mediaPlayerfx_trap = MediaPlayer.create(getApplicationContext(), R.raw.fx_trap);
        mediaPlayeroito08 = MediaPlayer.create(getApplicationContext(), R.raw.oito08);
        mediaPlayerbeattrap = MediaPlayer.create(getApplicationContext(), R.raw.beattrap);
    }

    @Override
    public void onBackPressed() { //Botão BACK padrão do android
        Intent intentvoltar = new Intent(getApplicationContext(), EscolherInstrumentoBeat.class);
        startActivity(intentvoltar);
        mediaPlayerclaptrap.stop();
        mediaPlayerclaptrap.release();
        mediaPlayerhi_hattrap.stop();
        mediaPlayerhi_hattrap.release();
        mediaPlayerkicktrap.stop();
        mediaPlayerkicktrap.release();
        mediaPlayerpre_music1trap.stop();
        mediaPlayerpre_music1trap.release();
        mediaPlayerfx_trap.stop();
        mediaPlayerfx_trap.release();
        mediaPlayeroito08.stop();
        mediaPlayeroito08.release();
        mediaPlayerbeattrap.stop();
        mediaPlayerbeattrap.release();
    }
    public void tocar_claptrap(View view) {
        if(mediaPlayerclaptrap != null) {
            mediaPlayerclaptrap.start();
        } if( mediaPlayerclaptrap.isPlaying()){
            mediaPlayerclaptrap.seekTo(0);
            mediaPlayerclaptrap.start();
        }
    }
    public void tocar_hi_hattrap(View view){
        san = san + 1;
        san = san + 1;
        if (san == 2) {
            mediaPlayerhi_hattrap.start();
            mediaPlayerhi_hattrap.setLooping(true);
            san = san + 1;
        }
        if (san == 5){
            mediaPlayerhi_hattrap.setLooping(false);
            mediaPlayerhi_hattrap.pause();
            san = 0;
        }
    }
    public void tocar_kicktrap(View view) {
        if(mediaPlayerkicktrap != null) {
            mediaPlayerkicktrap.start();
        } if( mediaPlayerkicktrap.isPlaying()){
            mediaPlayerkicktrap.seekTo(0);
            mediaPlayerkicktrap.start();
        }
    }
    public void tocar_fx_trap(View view) {
        if(mediaPlayerfx_trap != null) {
            mediaPlayerfx_trap.start();
        } if( mediaPlayerfx_trap.isPlaying()){
            mediaPlayerfx_trap.seekTo(0);
            mediaPlayerfx_trap.start();
        }
    }
    public void tocar_oito08(View view) {
        if(mediaPlayeroito08 != null) {
            mediaPlayeroito08.start();
        } if( mediaPlayeroito08.isPlaying()){
            mediaPlayeroito08.seekTo(0);
            mediaPlayeroito08.start();
        }
    }
    public void tocar_pre_music1trap(View view){
        hi = hi + 1;
        hi = hi + 1;
        if (hi == 2) {
            mediaPlayerpre_music1trap.start();
            mediaPlayerpre_music1trap.setLooping(true);
            hi = hi + 1;
        }
        if (hi == 5){
            mediaPlayerpre_music1trap.setLooping(false);
            mediaPlayerpre_music1trap.pause();
            hi = 0;
        }
    }
    public void tocar_beattrap(View view){
        pre = pre + 1;
        pre = pre + 1;
        if (pre == 2) {
            mediaPlayerbeattrap.start();
            mediaPlayerbeattrap.setLooping(true);
            pre = pre + 1;
        }
        if (pre == 5){
            mediaPlayerbeattrap.setLooping(false);
            mediaPlayerbeattrap.pause();
            pre = 0;
        }
    }

}
