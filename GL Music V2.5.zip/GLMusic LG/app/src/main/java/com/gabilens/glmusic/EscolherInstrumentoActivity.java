package com.gabilens.glmusic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class EscolherInstrumentoActivity extends AppCompatActivity {

    private Button buttonviolao;
    private Button voltar;
    private Button buttonpiano;
    private Button buttonflauta;
    private Button buttonguitarra;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_escolher_instrumento);

        buttonpiano = findViewById(R.id.buttonpiano);
        buttonpiano.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), TocarNotasPiano.class);
                startActivity(intent);
            }
        });

        buttonviolao = findViewById(R.id.buttonviolao);
        buttonviolao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), TocarNotasViolao.class);
                startActivity(intent);
            }
        });

        buttonflauta = findViewById(R.id.buttonflauta);
        buttonflauta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), TocarNotasFlauta.class);
                startActivity(intent);
            }
        });

        buttonguitarra = findViewById(R.id.buttonguitarra);
        buttonguitarra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), TocarNotasGuitarra.class);
                startActivity(intent);
            }
        });

        voltar = findViewById(R.id.voltar);
        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentvoltar = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intentvoltar);
            }
        });
    }
}
